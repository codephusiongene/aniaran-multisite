<?php
/**
 * The template to display default site footer
 *
 * @package CONFIDANT
 * @since CONFIDANT 1.0.10
 */

$confidant_footer_id = confidant_get_custom_footer_id();
$confidant_footer_meta = get_post_meta( $confidant_footer_id, 'trx_addons_options', true );
if ( ! empty( $confidant_footer_meta['margin'] ) ) {
	confidant_add_inline_css( sprintf( '.page_content_wrap{padding-bottom:%s}', esc_attr( confidant_prepare_css_value( $confidant_footer_meta['margin'] ) ) ) );
}
?>
<footer class="footer_wrap footer_custom footer_custom_<?php echo esc_attr( $confidant_footer_id ); ?> footer_custom_<?php echo esc_attr( sanitize_title( get_the_title( $confidant_footer_id ) ) ); ?>
						<?php
						$confidant_footer_scheme = confidant_get_theme_option( 'footer_scheme' );
						if ( ! empty( $confidant_footer_scheme ) && ! confidant_is_inherit( $confidant_footer_scheme  ) ) {
							echo ' scheme_' . esc_attr( $confidant_footer_scheme );
						}
						?>
						">
	<?php
	// Custom footer's layout
	do_action( 'confidant_action_show_layout', $confidant_footer_id );
	?>
</footer><!-- /.footer_wrap -->
